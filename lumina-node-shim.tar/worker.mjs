import init, { run_worker, NodeClient, NodeConfig } from "lumina-node-wasm"

export default async function start_worker() {
	await init();
	let worker = new Worker(new URL("worker.mjs", import.meta.url));
	let client = new NodeClient(worker);
	return client;
}

Error.stackTraceLimit = 99;

// for SharedWorker we queue incoming connections
// for dedicated Worker we queue incoming messages (coming from the single client)
let queued = [];
function onMessage(event) {
	queued.push(event);
}

function onerror(event) {
	console.error("Worker error:", event);
}

if (typeof WorkerGlobalScope !== "undefined" &&
	typeof self !== "undefined" &&
	self instanceof WorkerGlobalScope) {

	init().then(() => {
		run_worker(queued);
	})
}

export { Network, NodeClient, NodeConfig } from "lumina-node-wasm";
